mvp_for_Adv_Python_Web_Book
===========================

This is the sample application that is used throughout the Adv Python for the web book.
